# Owned-cache Torch experiment

Device: `cuda`. This is a sequential reference-runner experiment, not a serving-throughput benchmark.

Mode: **free_generation**. Answers and their lengths may differ; this run tests quality and observed session behavior, not equal computational work.

Full-session time includes original prefill, pause/compression, restore or recomputation, generation and canceled-session work. A speed ratio above 1 means less full-session time than fixed INT4 in this run. Memory is peak retained serialized cache, not total GPU or process memory.

| Context target | Scenario | Policy | Mean full session (ms) | Speed ratio vs INT4 | Ratio vs admit-if-fits | Peak stored MiB | Correct / responses | Answer tokens identical to recompute |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 512 | cancellation | adaptive_eviction | 300.63 | 1.237× | 0.987× | 11.086 | 18/54 | 54/54 |
| 512 | cancellation | adaptive_exact | 304.31 | 1.222× | 0.975× | 11.098 | 18/54 | 54/54 |
| 512 | cancellation | group_int4 | 371.74 | 1.000× | 0.798× | 10.352 | 15/54 | 30/54 |
| 512 | cancellation | raw_admit_if_fits | 296.81 | 1.252× | 1.000× | 11.086 | 18/54 | 54/54 |
| 512 | cancellation | raw_native | 304.85 | 1.219× | 0.974× | 11.098 | 18/54 | 54/54 |
| 512 | cancellation | recompute | 321.08 | 1.158× | 0.924× | 0.000 | 18/54 | 54/54 |
| 512 | pressure | adaptive_eviction | 351.93 | 1.202× | 0.995× | 11.086 | 27/72 | 72/72 |
| 512 | pressure | adaptive_exact | 360.12 | 1.175× | 0.972× | 11.098 | 27/72 | 72/72 |
| 512 | pressure | group_int4 | 423.02 | 1.000× | 0.828× | 10.352 | 18/72 | 36/72 |
| 512 | pressure | raw_admit_if_fits | 350.07 | 1.208× | 1.000× | 11.086 | 27/72 | 72/72 |
| 512 | pressure | raw_native | 360.78 | 1.173× | 0.970× | 11.098 | 27/72 | 72/72 |
| 512 | pressure | recompute | 376.95 | 1.122× | 0.929× | 0.000 | 27/72 | 72/72 |
| 512 | roomy | adaptive_eviction | 277.28 | 1.515× | 1.005× | 44.240 | 27/72 | 72/72 |
| 512 | roomy | adaptive_exact | 278.07 | 1.510× | 1.003× | 44.240 | 27/72 | 72/72 |
| 512 | roomy | group_int4 | 419.97 | 1.000× | 0.664× | 11.822 | 15/72 | 27/72 |
| 512 | roomy | raw_admit_if_fits | 278.79 | 1.506× | 1.000× | 44.240 | 27/72 | 72/72 |
| 512 | roomy | raw_native | 278.55 | 1.508× | 1.001× | 44.240 | 27/72 | 72/72 |
| 512 | roomy | recompute | 377.67 | 1.112× | 0.738× | 0.000 | 27/72 | 72/72 |
| 2048 | cancellation | adaptive_eviction | 911.19 | 1.438× | 0.965× | 47.145 | 51/54 | 54/54 |
| 2048 | cancellation | adaptive_exact | 917.54 | 1.428× | 0.958× | 47.133 | 51/54 | 54/54 |
| 2048 | cancellation | group_int4 | 1310.04 | 1.000× | 0.671× | 43.818 | 24/54 | 24/54 |
| 2048 | cancellation | raw_admit_if_fits | 879.05 | 1.490× | 1.000× | 47.110 | 51/54 | 54/54 |
| 2048 | cancellation | raw_native | 916.84 | 1.429× | 0.959× | 47.133 | 51/54 | 54/54 |
| 2048 | cancellation | recompute | 966.73 | 1.355× | 0.909× | 0.000 | 51/54 | 54/54 |
| 2048 | pressure | adaptive_eviction | 1015.31 | 1.437× | 0.999× | 47.110 | 60/72 | 72/72 |
| 2048 | pressure | adaptive_exact | 1053.29 | 1.386× | 0.963× | 47.133 | 60/72 | 72/72 |
| 2048 | pressure | group_int4 | 1459.35 | 1.000× | 0.695× | 43.818 | 33/72 | 33/72 |
| 2048 | pressure | raw_admit_if_fits | 1014.46 | 1.439× | 1.000× | 47.110 | 60/72 | 72/72 |
| 2048 | pressure | raw_native | 1048.77 | 1.391× | 0.967× | 47.133 | 60/72 | 72/72 |
| 2048 | pressure | recompute | 1111.57 | 1.313× | 0.913× | 0.000 | 60/72 | 72/72 |
| 2048 | roomy | adaptive_eviction | 723.03 | 2.020× | 1.000× | 188.241 | 60/72 | 72/72 |
| 2048 | roomy | adaptive_exact | 721.65 | 2.024× | 1.002× | 188.241 | 60/72 | 72/72 |
| 2048 | roomy | group_int4 | 1460.33 | 1.000× | 0.495× | 50.073 | 27/72 | 27/72 |
| 2048 | roomy | raw_admit_if_fits | 723.31 | 2.019× | 1.000× | 188.241 | 60/72 | 72/72 |
| 2048 | roomy | raw_native | 727.23 | 2.008× | 0.995× | 188.241 | 60/72 | 72/72 |
| 2048 | roomy | recompute | 1114.47 | 1.310× | 0.649× | 0.000 | 60/72 | 72/72 |

These are descriptive results on generated lookup, two-hop and arithmetic tasks. Repeated questions are not independent quality observations. Unchanged accuracy does not imply unchanged answers. No quality-preservation or general performance claim is certified.

`summary.json` also reports p95 resume time, truncations, baseline-relative quality regressions, sampled process RSS and CUDA allocator peaks. RSS sampling can miss short peaks. CPU compression follows native export, so compressed stored bytes are not reduced GPU-to-host transfer bytes.

Run `python scripts/validate_p100_results.py RUN_DIRECTORY` to independently audit archive hashes, accounting, completeness and scores.
