# Owned-cache Torch experiment

Device: `cuda`. This is a sequential reference-runner experiment, not a serving-throughput benchmark.

Mode: **equal_work**. Every policy consumes the same frozen continuation IDs for the same number of prediction steps, including EOS. These are teacher-forced computational controls, not generated answers; no quality score is assigned. Compare timings within this mode only.

Full-session time includes original prefill, pause/compression, restore or recomputation, generation and canceled-session work. A speed ratio above 1 means less full-session time than fixed INT4 in this run. Memory is peak retained serialized cache, not total GPU or process memory.

| Context target | Scenario | Policy | Mean full session (ms) | Speed ratio vs INT4 | Ratio vs admit-if-fits | Peak stored MiB | Correct / responses | Answer tokens identical to recompute |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 512 | cancellation | adaptive_eviction | 695.44 | 1.099× | 0.993× | 11.086 | n/a | n/a |
| 512 | cancellation | adaptive_exact | 697.41 | 1.096× | 0.990× | 11.098 | n/a | n/a |
| 512 | cancellation | group_int4 | 764.48 | 1.000× | 0.903× | 10.352 | n/a | n/a |
| 512 | cancellation | raw_admit_if_fits | 690.50 | 1.107× | 1.000× | 11.086 | n/a | n/a |
| 512 | cancellation | raw_native | 696.51 | 1.098× | 0.991× | 11.098 | n/a | n/a |
| 512 | cancellation | recompute | 708.32 | 1.079× | 0.975× | 0.000 | n/a | n/a |
| 512 | pressure | adaptive_eviction | 882.86 | 1.074× | 0.999× | 11.086 | n/a | n/a |
| 512 | pressure | adaptive_exact | 888.17 | 1.068× | 0.993× | 11.098 | n/a | n/a |
| 512 | pressure | group_int4 | 948.41 | 1.000× | 0.930× | 10.352 | n/a | n/a |
| 512 | pressure | raw_admit_if_fits | 881.75 | 1.076× | 1.000× | 11.086 | n/a | n/a |
| 512 | pressure | raw_native | 889.67 | 1.066× | 0.991× | 11.098 | n/a | n/a |
| 512 | pressure | recompute | 898.17 | 1.056× | 0.982× | 0.000 | n/a | n/a |
| 512 | roomy | adaptive_eviction | 814.54 | 1.157× | 0.997× | 44.240 | n/a | n/a |
| 512 | roomy | adaptive_exact | 812.07 | 1.161× | 1.000× | 44.240 | n/a | n/a |
| 512 | roomy | group_int4 | 942.58 | 1.000× | 0.862× | 11.822 | n/a | n/a |
| 512 | roomy | raw_admit_if_fits | 812.16 | 1.161× | 1.000× | 44.240 | n/a | n/a |
| 512 | roomy | raw_native | 810.67 | 1.163× | 1.002× | 44.240 | n/a | n/a |
| 512 | roomy | recompute | 903.75 | 1.043× | 0.899× | 0.000 | n/a | n/a |
| 2048 | cancellation | adaptive_eviction | 1272.26 | 1.211× | 0.979× | 47.145 | n/a | n/a |
| 2048 | cancellation | adaptive_exact | 1278.19 | 1.206× | 0.974× | 47.133 | n/a | n/a |
| 2048 | cancellation | group_int4 | 1541.11 | 1.000× | 0.808× | 43.818 | n/a | n/a |
| 2048 | cancellation | raw_admit_if_fits | 1244.92 | 1.238× | 1.000× | 47.110 | n/a | n/a |
| 2048 | cancellation | raw_native | 1275.13 | 1.209× | 0.976× | 47.133 | n/a | n/a |
| 2048 | cancellation | recompute | 1322.07 | 1.166× | 0.942× | 0.000 | n/a | n/a |
| 2048 | pressure | adaptive_eviction | 1506.44 | 1.172× | 1.007× | 47.110 | n/a | n/a |
| 2048 | pressure | adaptive_exact | 1543.15 | 1.144× | 0.983× | 47.133 | n/a | n/a |
| 2048 | pressure | group_int4 | 1765.90 | 1.000× | 0.859× | 43.818 | n/a | n/a |
| 2048 | pressure | raw_admit_if_fits | 1516.41 | 1.165× | 1.000× | 47.110 | n/a | n/a |
| 2048 | pressure | raw_native | 1551.93 | 1.138× | 0.977× | 47.133 | n/a | n/a |
| 2048 | pressure | recompute | 1601.75 | 1.102× | 0.947× | 0.000 | n/a | n/a |
| 2048 | roomy | adaptive_eviction | 1235.97 | 1.408× | 1.006× | 188.241 | n/a | n/a |
| 2048 | roomy | adaptive_exact | 1236.21 | 1.408× | 1.006× | 188.241 | n/a | n/a |
| 2048 | roomy | group_int4 | 1740.37 | 1.000× | 0.714× | 50.073 | n/a | n/a |
| 2048 | roomy | raw_admit_if_fits | 1243.45 | 1.400× | 1.000× | 188.241 | n/a | n/a |
| 2048 | roomy | raw_native | 1232.66 | 1.412× | 1.009× | 188.241 | n/a | n/a |
| 2048 | roomy | recompute | 1603.07 | 1.086× | 0.776× | 0.000 | n/a | n/a |

These are descriptive results on generated lookup, two-hop and arithmetic tasks. Repeated questions are not independent quality observations. Unchanged accuracy does not imply unchanged answers. No quality-preservation or general performance claim is certified.

`summary.json` also reports p95 resume time, truncations, baseline-relative quality regressions, sampled process RSS and CUDA allocator peaks. RSS sampling can miss short peaks. CPU compression follows native export, so compressed stored bytes are not reduced GPU-to-host transfer bytes.

Run `python scripts/validate_p100_results.py RUN_DIRECTORY` to independently audit archive hashes, accounting, completeness and scores.
