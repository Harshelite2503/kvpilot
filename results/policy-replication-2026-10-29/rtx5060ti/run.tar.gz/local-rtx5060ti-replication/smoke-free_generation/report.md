# Owned-cache Torch experiment

Device: `cuda`. This is a sequential reference-runner experiment, not a serving-throughput benchmark.

Mode: **free_generation**. Answers and their lengths may differ; this run tests quality and observed session behavior, not equal computational work.

Full-session time includes original prefill, pause/compression, restore or recomputation, generation and canceled-session work. A speed ratio above 1 means less full-session time than fixed INT4 in this run. Memory is peak retained serialized cache, not total GPU or process memory.

| Context target | Scenario | Policy | Mean full session (ms) | Speed ratio vs INT4 | Ratio vs admit-if-fits | Peak stored MiB | Correct / responses | Answer tokens identical to recompute |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 256 | pressure | adaptive_eviction | 240.35 | 1.394× | 0.995× | 2.526 | 1/4 | 4/4 |
| 256 | pressure | adaptive_exact | 246.91 | 1.357× | 0.969× | 2.526 | 1/4 | 4/4 |
| 256 | pressure | group_int4 | 335.02 | 1.000× | 0.714× | 1.992 | 1/4 | 2/4 |
| 256 | pressure | raw_admit_if_fits | 239.16 | 1.401× | 1.000× | 2.526 | 1/4 | 4/4 |
| 256 | pressure | raw_native | 253.31 | 1.323× | 0.944× | 2.526 | 1/4 | 4/4 |
| 256 | pressure | recompute | 259.97 | 1.289× | 0.920× | 0.000 | 1/4 | 4/4 |
| 256 | roomy | adaptive_eviction | 206.41 | 1.597× | 0.999× | 9.926 | 1/4 | 4/4 |
| 256 | roomy | adaptive_exact | 206.45 | 1.597× | 0.999× | 9.926 | 1/4 | 4/4 |
| 256 | roomy | group_int4 | 329.74 | 1.000× | 0.625× | 2.672 | 1/4 | 1/4 |
| 256 | roomy | raw_admit_if_fits | 206.18 | 1.599× | 1.000× | 9.926 | 1/4 | 4/4 |
| 256 | roomy | raw_native | 206.70 | 1.595× | 0.997× | 9.926 | 1/4 | 4/4 |
| 256 | roomy | recompute | 251.56 | 1.311× | 0.820× | 0.000 | 1/4 | 4/4 |

These are descriptive results on generated lookup, two-hop and arithmetic tasks. Repeated questions are not independent quality observations. Unchanged accuracy does not imply unchanged answers. No quality-preservation or general performance claim is certified.

`summary.json` also reports p95 resume time, truncations, baseline-relative quality regressions, sampled process RSS and CUDA allocator peaks. RSS sampling can miss short peaks. CPU compression follows native export, so compressed stored bytes are not reduced GPU-to-host transfer bytes.

Run `python scripts/validate_p100_results.py RUN_DIRECTORY` to independently audit archive hashes, accounting, completeness and scores.
