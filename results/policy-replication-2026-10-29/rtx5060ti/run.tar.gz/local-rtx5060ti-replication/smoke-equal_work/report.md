# Owned-cache Torch experiment

Device: `cuda`. This is a sequential reference-runner experiment, not a serving-throughput benchmark.

Mode: **equal_work**. Every policy consumes the same frozen continuation IDs for the same number of prediction steps, including EOS. These are teacher-forced computational controls, not generated answers; no quality score is assigned. Compare timings within this mode only.

Full-session time includes original prefill, pause/compression, restore or recomputation, generation and canceled-session work. A speed ratio above 1 means less full-session time than fixed INT4 in this run. Memory is peak retained serialized cache, not total GPU or process memory.

| Context target | Scenario | Policy | Mean full session (ms) | Speed ratio vs INT4 | Ratio vs admit-if-fits | Peak stored MiB | Correct / responses | Answer tokens identical to recompute |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 256 | pressure | adaptive_eviction | 787.69 | 1.049× | 1.004× | 2.526 | n/a | n/a |
| 256 | pressure | adaptive_exact | 794.70 | 1.040× | 0.995× | 2.526 | n/a | n/a |
| 256 | pressure | group_int4 | 826.42 | 1.000× | 0.957× | 1.992 | n/a | n/a |
| 256 | pressure | raw_admit_if_fits | 790.68 | 1.045× | 1.000× | 2.526 | n/a | n/a |
| 256 | pressure | raw_native | 795.67 | 1.039× | 0.994× | 2.526 | n/a | n/a |
| 256 | pressure | recompute | 802.79 | 1.029× | 0.985× | 0.000 | n/a | n/a |
| 256 | roomy | adaptive_eviction | 754.40 | 1.087× | 1.021× | 9.926 | n/a | n/a |
| 256 | roomy | adaptive_exact | 755.00 | 1.086× | 1.020× | 9.926 | n/a | n/a |
| 256 | roomy | group_int4 | 820.12 | 1.000× | 0.939× | 2.672 | n/a | n/a |
| 256 | roomy | raw_admit_if_fits | 770.08 | 1.065× | 1.000× | 9.926 | n/a | n/a |
| 256 | roomy | raw_native | 756.71 | 1.084× | 1.018× | 9.926 | n/a | n/a |
| 256 | roomy | recompute | 803.07 | 1.021× | 0.959× | 0.000 | n/a | n/a |

These are descriptive results on generated lookup, two-hop and arithmetic tasks. Repeated questions are not independent quality observations. Unchanged accuracy does not imply unchanged answers. No quality-preservation or general performance claim is certified.

`summary.json` also reports p95 resume time, truncations, baseline-relative quality regressions, sampled process RSS and CUDA allocator peaks. RSS sampling can miss short peaks. CPU compression follows native export, so compressed stored bytes are not reduced GPU-to-host transfer bytes.

Run `python scripts/validate_p100_results.py RUN_DIRECTORY` to independently audit archive hashes, accounting, completeness and scores.
