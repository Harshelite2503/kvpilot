#!/usr/bin/env python3
"""Capture an allowlisted benchmark runtime description without changing settings."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sys


ENVIRONMENT_KEYS = (
    "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS", "OMP_PROC_BIND", "OMP_PLACES",
    "CUDA_VISIBLE_DEVICES", "NVIDIA_VISIBLE_DEVICES", "CUBLAS_WORKSPACE_CONFIG",
    "NVIDIA_TF32_OVERRIDE", "TORCH_ALLOW_TF32_CUBLAS_OVERRIDE",
    "PYTORCH_CUDA_ALLOC_CONF", "PYTORCH_ALLOC_CONF", "TOKENIZERS_PARALLELISM",
)


def attempt(function):
    try:
        return function()
    except Exception as error:
        # Exception messages can contain arbitrary third-party configuration.
        return {"unavailable": type(error).__name__}


def read_control(path):
    file = Path(path)
    return file.read_text(encoding="utf-8").strip() if file.is_file() else None


def collect():
    import torch

    report = {
        "evidence_type": "runtime_configuration_snapshot",
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "settings_changed_by_capture": False,
        "python": platform.python_version(),
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "logical_cpu_count": os.cpu_count(),
        "cpu_affinity": attempt(lambda: sorted(os.sched_getaffinity(0))),
        "cgroup_cpu_max": attempt(lambda: read_control("/sys/fs/cgroup/cpu.max")),
        "cgroup_cpuset_effective": attempt(lambda: read_control("/sys/fs/cgroup/cpuset.cpus.effective")),
        "environment_allowlist": {key: os.environ.get(key) for key in ENVIRONMENT_KEYS},
        "packages": {name: attempt(lambda name=name: importlib.metadata.version(name))
                     for name in ("torch", "numpy", "tokenizers", "safetensors", "psutil", "pytest")},
        "torch": {
            "version": str(torch.__version__),
            "cuda_runtime": torch.version.cuda,
            "num_threads": torch.get_num_threads(),
            "num_interop_threads": torch.get_num_interop_threads(),
            "default_dtype": str(torch.get_default_dtype()),
            "float32_matmul_precision": torch.get_float32_matmul_precision(),
            "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
            "matmul_allow_fp16_reduced_precision_reduction": torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction,
            "matmul_allow_bf16_reduced_precision_reduction": torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
            "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
            "cudnn_benchmark": torch.backends.cudnn.benchmark,
            "cudnn_deterministic": torch.backends.cudnn.deterministic,
            "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
            "deterministic_warn_only": torch.is_deterministic_algorithms_warn_only_enabled(),
            "cuda_available": torch.cuda.is_available(),
            "compiled_architectures": attempt(torch.cuda.get_arch_list),
        },
        "comparability": {
            "source_attention": "owned eager Qwen attention: explicit FP32 scores, softmax and value multiplication",
            "requested_activation_dtype": "float16",
            "controls": "No CPU thread, TF32, precision, determinism or allocator setting is changed by this script.",
            "limits": "Different host CPU, PCIe, driver and CUDA wheel prevent a pure GPU-only causal comparison. Equal-work continuations are frozen independently per run; compare token arrays across hardware before claiming identical inputs.",
        },
    }
    if torch.cuda.is_available():
        devices = []
        for index in range(torch.cuda.device_count()):
            properties = torch.cuda.get_device_properties(index)
            devices.append({
                "index": index,
                "name": properties.name,
                "compute_capability": list(torch.cuda.get_device_capability(index)),
                "total_memory_bytes": int(properties.total_memory),
                "multiprocessor_count": properties.multi_processor_count,
            })
        report["torch"]["devices"] = devices
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    report = collect()
    content = json.dumps(report, indent=2, allow_nan=False) + "\n"
    with args.output.open("x", encoding="utf-8") as stream:
        stream.write(content)
    print(content, end="")


if __name__ == "__main__":
    main()
