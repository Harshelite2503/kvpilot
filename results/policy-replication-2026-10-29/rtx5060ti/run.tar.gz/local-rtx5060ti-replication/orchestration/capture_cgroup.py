"""Read legacy CPU quota files; do not alter runtime settings."""
import json
from datetime import datetime, timezone
from pathlib import Path

paths = (
    "/sys/fs/cgroup/cpu/cpu.cfs_quota_us",
    "/sys/fs/cgroup/cpu/cpu.cfs_period_us",
    "/sys/fs/cgroup/cpu,cpuacct/cpu.cfs_quota_us",
    "/sys/fs/cgroup/cpu,cpuacct/cpu.cfs_period_us",
)
record = {"evidence_type": "legacy_cpu_quota_snapshot",
          "captured_utc": datetime.now(timezone.utc).isoformat(),
          "settings_changed": False,
          "values": {name: Path(name).read_text().strip() if Path(name).is_file() else None
                     for name in paths}}
target = Path("/workspace/kvpilot/results/local-rtx5060ti-replication/runtime-legacy-cgroup.json")
with target.open("x") as output:
    json.dump(record, output, indent=2)
print(json.dumps(record))
