#!/usr/bin/env bash
# RTX 5060 Ti replication of the P100 suite, with unchanged benchmark source.
# Dependencies and pinned model must already exist. No account credentials needed.
set -euo pipefail
umask 077

KVPILOT_ROOT="/workspace/kvpilot"
KVPILOT_PYTHON="/workspace/kvpilot-env/bin/python"
KVPILOT_MODEL="/workspace/kvpilot/data/qwen25-05b-pinned"
KVPILOT_OUTPUT="/workspace/kvpilot/results/local-rtx5060ti-replication"
KVPILOT_EXPECTED_COMMIT="ca6f6feaaf7faef4b942bd37d78ee29ded99a27a"
KVPILOT_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KVPILOT_PHASE="initialization"
KVPILOT_STARTED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

if [[ ! -x "$KVPILOT_PYTHON" || ! -d "$KVPILOT_ROOT/.git" ]]; then
  echo "Missing prepared Python environment or Git checkout." >&2
  exit 2
fi
if [[ -e "$KVPILOT_OUTPUT" || -e "$KVPILOT_OUTPUT.tar.gz" ]]; then
  echo "Refusing to overwrite existing result evidence: $KVPILOT_OUTPUT" >&2
  exit 2
fi
mkdir -p "$(dirname "$KVPILOT_OUTPUT")"
mkdir "$KVPILOT_OUTPUT"
cd "$KVPILOT_ROOT"

finish() {
  local result=$?
  trap - EXIT
  set +e
  "$KVPILOT_PYTHON" - "$KVPILOT_OUTPUT" "$result" "$KVPILOT_PHASE" "$KVPILOT_STARTED_UTC" <<'PY'
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
root, code, phase, started = sys.argv[1:]
status = {"evidence_type": "external_replication_suite_status", "completed": int(code) == 0,
          "exit_code": int(code), "last_phase": phase, "started_utc": started,
          "finished_utc": datetime.now(timezone.utc).isoformat(),
          "device_label": "RTX 5060 Ti", "partial_evidence": int(code) != 0,
          "scope": "Completed means all suite commands and independent audits passed; it does not certify speed or answer preservation."}
(Path(root) / "suite-status.json").write_text(json.dumps(status, indent=2) + "\n")
PY
  if [[ $? -ne 0 && $result -eq 0 ]]; then result=1; fi
  nvidia-smi -q > "$KVPILOT_OUTPUT/nvidia-smi-final.txt" 2>&1
  "$KVPILOT_PYTHON" - "$KVPILOT_OUTPUT" <<'PY'
from hashlib import sha256
import json
from pathlib import Path
import sys
root = Path(sys.argv[1])
records = {}
for path in sorted(root.rglob("*")):
    if path.is_file() and path.name != "suite-artifact-sha256.json":
        digest = sha256()
        with path.open("rb") as source:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(chunk)
        records[str(path.relative_to(root))] = digest.hexdigest()
(root / "suite-artifact-sha256.json").write_text(json.dumps(records, indent=2) + "\n")
PY
  if [[ $? -ne 0 && $result -eq 0 ]]; then result=1; fi
  if tar -czf "$KVPILOT_OUTPUT.tar.gz" -C "$(dirname "$KVPILOT_OUTPUT")" "$(basename "$KVPILOT_OUTPUT")"; then
    sha256sum "$KVPILOT_OUTPUT.tar.gz" | tee "$KVPILOT_OUTPUT.tar.gz.sha256"
  else
    echo "Bundle creation failed; preserve the result directory directly." >&2
    if [[ $result -eq 0 ]]; then result=1; fi
  fi
  if [[ $result -eq 0 ]]; then
    echo "Suite complete. Result bundle: $KVPILOT_OUTPUT.tar.gz"
  else
    echo "Suite failed in phase '$KVPILOT_PHASE' (exit $result). Partial evidence preserved at $KVPILOT_OUTPUT and, if packaging succeeded, $KVPILOT_OUTPUT.tar.gz" >&2
  fi
  exit "$result"
}
trap finish EXIT

phase() {
  local label="$1"
  shift
  KVPILOT_PHASE="$label"
  printf '%s\t%s\tstarted\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$label" >> "$KVPILOT_OUTPUT/phases.tsv"
  echo "PHASE $label"
  local result=0
  "$@" 2>&1 | tee "$KVPILOT_OUTPUT/$label.log" || result=$?
  printf '%s\t%s\texit=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$label" "$result" >> "$KVPILOT_OUTPUT/phases.tsv"
  return "$result"
}

check_source() {
  git rev-parse HEAD | tee "$KVPILOT_OUTPUT/source-commit.txt" || return
  git status --short | tee "$KVPILOT_OUTPUT/git-status.txt" || return
  [[ "$(git rev-parse HEAD)" == "$KVPILOT_EXPECTED_COMMIT" ]] || return
  git diff --quiet || return
  git diff --cached --quiet || return
}

check_device() {
  "$KVPILOT_PYTHON" - "$KVPILOT_OUTPUT/preflight.json" <<'PY'
import json
from pathlib import Path
import sys
data = json.loads(Path(sys.argv[1]).read_text())
assert data["ok"] is True, "Preflight did not pass"
assert "RTX 5060 Ti" in data["device_name"], "Unexpected GPU model"
assert data["compute_capability"] == [12, 0], "Unexpected compute capability"
assert data["total_device_bytes"] >= 15 * 1024**3, "This is not the requested 16GB card"
assert data["torch_version"] == "2.7.1+cu128", "Unexpected Torch build"
assert "sm_120" in data["compiled_arches"], "Wheel does not contain sm_120 kernels"
print("Verified RTX 5060 Ti 16GB, compute capability 12.0, Torch 2.7.1+cu128 and sm_120 kernels.")
PY
}

mkdir "$KVPILOT_OUTPUT/orchestration"
cp "$KVPILOT_SCRIPT_DIR/$(basename "${BASH_SOURCE[0]}")" "$KVPILOT_OUTPUT/orchestration/remote-run.sh"
cp "$KVPILOT_SCRIPT_DIR/capture_runtime.py" "$KVPILOT_OUTPUT/orchestration/capture_runtime.py"
sha256sum "$KVPILOT_OUTPUT/orchestration/remote-run.sh" "$KVPILOT_OUTPUT/orchestration/capture_runtime.py" > "$KVPILOT_OUTPUT/orchestration-sha256.txt"

phase source-check check_source
phase runtime-capture "$KVPILOT_PYTHON" "$KVPILOT_SCRIPT_DIR/capture_runtime.py" --output "$KVPILOT_OUTPUT/runtime.json"
phase pip-freeze "$KVPILOT_PYTHON" -m pip freeze --all
phase nvidia-smi nvidia-smi -q
phase nvidia-smi-xml nvidia-smi -q -x
phase uname uname -a
phase lscpu lscpu
phase preflight "$KVPILOT_PYTHON" scripts/p100_preflight.py --device cuda --allow-other-cuda --output "$KVPILOT_OUTPUT/preflight.json"
phase device-check check_device
phase model-check "$KVPILOT_PYTHON" scripts/download_p100_model.py --check-only --model-dir "$KVPILOT_MODEL"
cp "$KVPILOT_MODEL/model-manifest.json" "$KVPILOT_OUTPUT/model-manifest.json"
cp "$KVPILOT_SCRIPT_DIR/capture_cgroup.py" "$KVPILOT_OUTPUT/orchestration/capture_cgroup.py"
"$KVPILOT_PYTHON" "$KVPILOT_SCRIPT_DIR/capture_cgroup.py"
phase tests "$KVPILOT_PYTHON" -m pytest -q --junitxml="$KVPILOT_OUTPUT/tests.xml"

for KVPILOT_MODE in equal_work free_generation; do
  phase "smoke-$KVPILOT_MODE" "$KVPILOT_PYTHON" -u scripts/benchmark_p100_kvpilot.py \
    --model-dir "$KVPILOT_MODEL" --device cuda --output "$KVPILOT_OUTPUT/smoke-$KVPILOT_MODE" \
    --smoke --timing-mode "$KVPILOT_MODE" --seed 20261102 --allow-unvalidated-lossy
  phase "smoke-$KVPILOT_MODE-validation" "$KVPILOT_PYTHON" scripts/validate_p100_results.py \
    "$KVPILOT_OUTPUT/smoke-$KVPILOT_MODE" --output "$KVPILOT_OUTPUT/smoke-$KVPILOT_MODE-validation.json"
  tar -czf "$KVPILOT_OUTPUT/smoke-$KVPILOT_MODE.tar.gz" -C "$KVPILOT_OUTPUT" "smoke-$KVPILOT_MODE"
  sha256sum "$KVPILOT_OUTPUT/smoke-$KVPILOT_MODE.tar.gz" > "$KVPILOT_OUTPUT/smoke-$KVPILOT_MODE.tar.gz.sha256"
done

for KVPILOT_MODE in equal_work free_generation; do
  phase "full-$KVPILOT_MODE" "$KVPILOT_PYTHON" -u scripts/benchmark_p100_kvpilot.py \
    --model-dir "$KVPILOT_MODEL" --device cuda --output "$KVPILOT_OUTPUT/full-$KVPILOT_MODE" \
    --contexts 512 2048 --cases 24 --repeats 3 --group-size 8 \
    --scenarios roomy pressure cancellation --max-tokens 24 --chunk-size 128 \
    --timing-mode "$KVPILOT_MODE" --seed 20261102 --allow-unvalidated-lossy
  phase "full-$KVPILOT_MODE-validation" "$KVPILOT_PYTHON" scripts/validate_p100_results.py \
    "$KVPILOT_OUTPUT/full-$KVPILOT_MODE" --output "$KVPILOT_OUTPUT/full-$KVPILOT_MODE-validation.json"
  tar -czf "$KVPILOT_OUTPUT/full-$KVPILOT_MODE.tar.gz" -C "$KVPILOT_OUTPUT" "full-$KVPILOT_MODE"
  sha256sum "$KVPILOT_OUTPUT/full-$KVPILOT_MODE.tar.gz" > "$KVPILOT_OUTPUT/full-$KVPILOT_MODE.tar.gz.sha256"
done

phase break-even "$KVPILOT_PYTHON" scripts/sweep_p100_break_even.py \
  --run-dir "$KVPILOT_OUTPUT/full-equal_work" --output "$KVPILOT_OUTPUT/break-even"
phase final-source-check check_source
KVPILOT_PHASE="complete"
