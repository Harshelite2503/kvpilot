# Owned-cache Torch experiment

Device: `cuda`. This is a sequential reference-runner experiment, not a serving-throughput benchmark.

Mode: **free_generation**. Answers and their lengths may differ; this run tests quality and observed session behavior, not equal computational work.

Full-session time includes original prefill, pause/compression, restore or recomputation, generation and canceled-session work. A speed ratio above 1 means less full-session time than fixed INT4 in this run. Memory is peak retained serialized cache, not total GPU or process memory.

| Context target | Scenario | Policy | Mean full session (ms) | Speed ratio vs INT4 | Ratio vs admit-if-fits | Peak stored MiB | Correct / responses | Answer tokens identical to recompute |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 256 | pressure | adaptive_eviction | 225.83 | 1.448× | 1.001× | 2.526 | 1/4 | 4/4 |
| 256 | pressure | adaptive_exact | 232.60 | 1.406× | 0.972× | 2.526 | 1/4 | 4/4 |
| 256 | pressure | group_int4 | 327.04 | 1.000× | 0.691× | 1.992 | 1/4 | 2/4 |
| 256 | pressure | raw_admit_if_fits | 226.15 | 1.446× | 1.000× | 2.526 | 1/4 | 4/4 |
| 256 | pressure | raw_native | 231.82 | 1.411× | 0.976× | 2.526 | 1/4 | 4/4 |
| 256 | pressure | recompute | 238.45 | 1.372× | 0.948× | 0.000 | 1/4 | 4/4 |
| 256 | roomy | adaptive_eviction | 193.89 | 1.677× | 1.055× | 9.926 | 1/4 | 4/4 |
| 256 | roomy | adaptive_exact | 194.52 | 1.671× | 1.052× | 9.926 | 1/4 | 4/4 |
| 256 | roomy | group_int4 | 325.10 | 1.000× | 0.629× | 2.672 | 1/4 | 1/4 |
| 256 | roomy | raw_admit_if_fits | 204.57 | 1.589× | 1.000× | 9.926 | 1/4 | 4/4 |
| 256 | roomy | raw_native | 194.35 | 1.673× | 1.053× | 9.926 | 1/4 | 4/4 |
| 256 | roomy | recompute | 241.94 | 1.344× | 0.846× | 0.000 | 1/4 | 4/4 |

These are descriptive results on generated lookup, two-hop and arithmetic tasks. Repeated questions are not independent quality observations. Unchanged accuracy does not imply unchanged answers. No quality-preservation or general performance claim is certified.

`summary.json` also reports p95 resume time, truncations, baseline-relative quality regressions, sampled process RSS and CUDA allocator peaks. RSS sampling can miss short peaks. CPU compression follows native export, so compressed stored bytes are not reduced GPU-to-host transfer bytes.

Run `python scripts/validate_p100_results.py RUN_DIRECTORY` to independently audit archive hashes, accounting, completeness and scores.
