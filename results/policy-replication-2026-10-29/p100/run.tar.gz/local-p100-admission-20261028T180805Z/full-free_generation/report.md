# Owned-cache Torch experiment

Device: `cuda`. This is a sequential reference-runner experiment, not a serving-throughput benchmark.

Mode: **free_generation**. Answers and their lengths may differ; this run tests quality and observed session behavior, not equal computational work.

Full-session time includes original prefill, pause/compression, restore or recomputation, generation and canceled-session work. A speed ratio above 1 means less full-session time than fixed INT4 in this run. Memory is peak retained serialized cache, not total GPU or process memory.

| Context target | Scenario | Policy | Mean full session (ms) | Speed ratio vs INT4 | Ratio vs admit-if-fits | Peak stored MiB | Correct / responses | Answer tokens identical to recompute |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 512 | cancellation | adaptive_eviction | 277.03 | 1.335× | 0.980× | 11.086 | 18/54 | 54/54 |
| 512 | cancellation | adaptive_exact | 281.11 | 1.315× | 0.965× | 11.098 | 18/54 | 54/54 |
| 512 | cancellation | group_int4 | 369.71 | 1.000× | 0.734× | 10.352 | 12/54 | 30/54 |
| 512 | cancellation | raw_admit_if_fits | 271.41 | 1.362× | 1.000× | 11.086 | 18/54 | 54/54 |
| 512 | cancellation | raw_native | 280.40 | 1.319× | 0.968× | 11.098 | 18/54 | 54/54 |
| 512 | cancellation | recompute | 289.25 | 1.278× | 0.938× | 0.000 | 18/54 | 54/54 |
| 512 | pressure | adaptive_eviction | 324.02 | 1.291× | 0.999× | 11.086 | 27/72 | 72/72 |
| 512 | pressure | adaptive_exact | 333.74 | 1.254× | 0.970× | 11.098 | 27/72 | 72/72 |
| 512 | pressure | group_int4 | 418.46 | 1.000× | 0.773× | 10.352 | 15/72 | 36/72 |
| 512 | pressure | raw_admit_if_fits | 323.64 | 1.293× | 1.000× | 11.086 | 27/72 | 72/72 |
| 512 | pressure | raw_native | 332.24 | 1.260× | 0.974× | 11.098 | 27/72 | 72/72 |
| 512 | pressure | recompute | 342.15 | 1.223× | 0.946× | 0.000 | 27/72 | 72/72 |
| 512 | roomy | adaptive_eviction | 261.11 | 1.610× | 1.011× | 44.240 | 27/72 | 72/72 |
| 512 | roomy | adaptive_exact | 259.56 | 1.620× | 1.017× | 44.240 | 27/72 | 72/72 |
| 512 | roomy | group_int4 | 420.42 | 1.000× | 0.628× | 11.822 | 12/72 | 27/72 |
| 512 | roomy | raw_admit_if_fits | 264.03 | 1.592× | 1.000× | 44.240 | 27/72 | 72/72 |
| 512 | roomy | raw_native | 262.05 | 1.604× | 1.008× | 44.240 | 27/72 | 72/72 |
| 512 | roomy | recompute | 346.15 | 1.215× | 0.763× | 0.000 | 27/72 | 72/72 |
| 2048 | cancellation | adaptive_eviction | 956.19 | 1.464× | 0.992× | 47.145 | 51/54 | 54/54 |
| 2048 | cancellation | adaptive_exact | 1027.09 | 1.363× | 0.924× | 47.133 | 51/54 | 54/54 |
| 2048 | cancellation | group_int4 | 1399.83 | 1.000× | 0.678× | 43.818 | 21/54 | 21/54 |
| 2048 | cancellation | raw_admit_if_fits | 948.99 | 1.475× | 1.000× | 47.110 | 51/54 | 54/54 |
| 2048 | cancellation | raw_native | 978.76 | 1.430× | 0.970× | 47.133 | 51/54 | 54/54 |
| 2048 | cancellation | recompute | 1038.44 | 1.348× | 0.914× | 0.000 | 51/54 | 54/54 |
| 2048 | pressure | adaptive_eviction | 1072.86 | 1.461× | 1.002× | 47.110 | 60/72 | 72/72 |
| 2048 | pressure | adaptive_exact | 1115.21 | 1.406× | 0.964× | 47.133 | 60/72 | 72/72 |
| 2048 | pressure | group_int4 | 1567.83 | 1.000× | 0.686× | 43.818 | 27/72 | 27/72 |
| 2048 | pressure | raw_admit_if_fits | 1075.11 | 1.458× | 1.000× | 47.110 | 60/72 | 72/72 |
| 2048 | pressure | raw_native | 1117.42 | 1.403× | 0.962× | 47.133 | 60/72 | 72/72 |
| 2048 | pressure | recompute | 1240.07 | 1.264× | 0.867× | 0.000 | 60/72 | 72/72 |
| 2048 | roomy | adaptive_eviction | 766.95 | 2.079× | 1.010× | 188.241 | 60/72 | 72/72 |
| 2048 | roomy | adaptive_exact | 759.18 | 2.100× | 1.021× | 188.241 | 60/72 | 72/72 |
| 2048 | roomy | group_int4 | 1594.33 | 1.000× | 0.486× | 50.073 | 18/72 | 18/72 |
| 2048 | roomy | raw_admit_if_fits | 774.91 | 2.057× | 1.000× | 188.241 | 60/72 | 72/72 |
| 2048 | roomy | raw_native | 764.59 | 2.085× | 1.013× | 188.241 | 60/72 | 72/72 |
| 2048 | roomy | recompute | 1213.90 | 1.313× | 0.638× | 0.000 | 60/72 | 72/72 |

These are descriptive results on generated lookup, two-hop and arithmetic tasks. Repeated questions are not independent quality observations. Unchanged accuracy does not imply unchanged answers. No quality-preservation or general performance claim is certified.

`summary.json` also reports p95 resume time, truncations, baseline-relative quality regressions, sampled process RSS and CUDA allocator peaks. RSS sampling can miss short peaks. CPU compression follows native export, so compressed stored bytes are not reduced GPU-to-host transfer bytes.

Run `python scripts/validate_p100_results.py RUN_DIRECTORY` to independently audit archive hashes, accounting, completeness and scores.
