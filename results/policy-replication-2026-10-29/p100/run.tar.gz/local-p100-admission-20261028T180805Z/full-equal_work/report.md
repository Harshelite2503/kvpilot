# Owned-cache Torch experiment

Device: `cuda`. This is a sequential reference-runner experiment, not a serving-throughput benchmark.

Mode: **equal_work**. Every policy consumes the same frozen continuation IDs for the same number of prediction steps, including EOS. These are teacher-forced computational controls, not generated answers; no quality score is assigned. Compare timings within this mode only.

Full-session time includes original prefill, pause/compression, restore or recomputation, generation and canceled-session work. A speed ratio above 1 means less full-session time than fixed INT4 in this run. Memory is peak retained serialized cache, not total GPU or process memory.

| Context target | Scenario | Policy | Mean full session (ms) | Speed ratio vs INT4 | Ratio vs admit-if-fits | Peak stored MiB | Correct / responses | Answer tokens identical to recompute |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 512 | cancellation | adaptive_eviction | 672.27 | 1.233× | 0.989× | 11.086 | n/a | n/a |
| 512 | cancellation | adaptive_exact | 723.47 | 1.146× | 0.919× | 11.098 | n/a | n/a |
| 512 | cancellation | group_int4 | 828.95 | 1.000× | 0.802× | 10.352 | n/a | n/a |
| 512 | cancellation | raw_admit_if_fits | 665.01 | 1.247× | 1.000× | 11.086 | n/a | n/a |
| 512 | cancellation | raw_native | 697.99 | 1.188× | 0.953× | 11.098 | n/a | n/a |
| 512 | cancellation | recompute | 690.74 | 1.200× | 0.963× | 0.000 | n/a | n/a |
| 512 | pressure | adaptive_eviction | 913.96 | 1.094× | 0.935× | 11.180 | n/a | n/a |
| 512 | pressure | adaptive_exact | 871.22 | 1.147× | 0.981× | 11.098 | n/a | n/a |
| 512 | pressure | group_int4 | 999.63 | 1.000× | 0.855× | 10.352 | n/a | n/a |
| 512 | pressure | raw_admit_if_fits | 854.43 | 1.170× | 1.000× | 11.086 | n/a | n/a |
| 512 | pressure | raw_native | 869.23 | 1.150× | 0.983× | 11.098 | n/a | n/a |
| 512 | pressure | recompute | 877.43 | 1.139× | 0.974× | 0.000 | n/a | n/a |
| 512 | roomy | adaptive_eviction | 788.98 | 1.212× | 1.025× | 44.240 | n/a | n/a |
| 512 | roomy | adaptive_exact | 804.16 | 1.189× | 1.006× | 44.240 | n/a | n/a |
| 512 | roomy | group_int4 | 956.27 | 1.000× | 0.846× | 11.822 | n/a | n/a |
| 512 | roomy | raw_admit_if_fits | 809.00 | 1.182× | 1.000× | 44.240 | n/a | n/a |
| 512 | roomy | raw_native | 792.87 | 1.206× | 1.020× | 44.240 | n/a | n/a |
| 512 | roomy | recompute | 962.11 | 0.994× | 0.841× | 0.000 | n/a | n/a |
| 2048 | cancellation | adaptive_eviction | 1465.87 | 1.117× | 0.942× | 47.145 | n/a | n/a |
| 2048 | cancellation | adaptive_exact | 1370.02 | 1.195× | 1.007× | 47.133 | n/a | n/a |
| 2048 | cancellation | group_int4 | 1637.42 | 1.000× | 0.843× | 43.818 | n/a | n/a |
| 2048 | cancellation | raw_admit_if_fits | 1380.14 | 1.186× | 1.000× | 47.110 | n/a | n/a |
| 2048 | cancellation | raw_native | 1404.09 | 1.166× | 0.983× | 47.133 | n/a | n/a |
| 2048 | cancellation | recompute | 1449.52 | 1.130× | 0.952× | 0.000 | n/a | n/a |
| 2048 | pressure | adaptive_eviction | 1697.94 | 1.113× | 0.940× | 47.110 | n/a | n/a |
| 2048 | pressure | adaptive_exact | 1673.19 | 1.129× | 0.954× | 47.133 | n/a | n/a |
| 2048 | pressure | group_int4 | 1888.97 | 1.000× | 0.845× | 43.818 | n/a | n/a |
| 2048 | pressure | raw_admit_if_fits | 1596.41 | 1.183× | 1.000× | 47.110 | n/a | n/a |
| 2048 | pressure | raw_native | 1718.54 | 1.099× | 0.929× | 47.133 | n/a | n/a |
| 2048 | pressure | recompute | 1712.91 | 1.103× | 0.932× | 0.000 | n/a | n/a |
| 2048 | roomy | adaptive_eviction | 1296.88 | 1.417× | 0.994× | 188.241 | n/a | n/a |
| 2048 | roomy | adaptive_exact | 1282.42 | 1.433× | 1.006× | 188.241 | n/a | n/a |
| 2048 | roomy | group_int4 | 1837.43 | 1.000× | 0.702× | 50.073 | n/a | n/a |
| 2048 | roomy | raw_admit_if_fits | 1289.65 | 1.425× | 1.000× | 188.241 | n/a | n/a |
| 2048 | roomy | raw_native | 1293.86 | 1.420× | 0.997× | 188.241 | n/a | n/a |
| 2048 | roomy | recompute | 1719.72 | 1.068× | 0.750× | 0.000 | n/a | n/a |

These are descriptive results on generated lookup, two-hop and arithmetic tasks. Repeated questions are not independent quality observations. Unchanged accuracy does not imply unchanged answers. No quality-preservation or general performance claim is certified.

`summary.json` also reports p95 resume time, truncations, baseline-relative quality regressions, sampled process RSS and CUDA allocator peaks. RSS sampling can miss short peaks. CPU compression follows native export, so compressed stored bytes are not reduced GPU-to-host transfer bytes.

Run `python scripts/validate_p100_results.py RUN_DIRECTORY` to independently audit archive hashes, accounting, completeness and scores.
