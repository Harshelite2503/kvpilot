# Counterfactual codec-cost sweep

**Modeled opportunity screen. No measured speedup, GPU-memory saving, quality guarantee or dollar saving is reported.**

Input timing mode: `equal_work`. Scales apply only to lossy encode/decode; native framing and all export/import costs remain.

All admitted cache work is charged even if its payload is later canceled or evicted. Recompute-arm generation work is held common. Full component costs and per-event decisions are in the JSON artifacts.

| Context | Scenario | Policy | Grid result vs recompute | First observed transition bracket |
| ---: | --- | --- | --- | --- |
| 512 | cancellation | adaptive_eviction | wins_entire_grid | none observed |
| 512 | cancellation | adaptive_exact | wins_entire_grid | none observed |
| 512 | cancellation | group_int4 | mixed_grid | [0.5, 0.75] (win → no win) |
| 512 | cancellation | raw_admit_if_fits | wins_entire_grid | none observed |
| 512 | cancellation | raw_native | wins_entire_grid | none observed |
| 512 | pressure | adaptive_eviction | wins_entire_grid | none observed |
| 512 | pressure | adaptive_exact | wins_entire_grid | none observed |
| 512 | pressure | group_int4 | mixed_grid | [0.5, 0.75] (win → no win) |
| 512 | pressure | raw_admit_if_fits | wins_entire_grid | none observed |
| 512 | pressure | raw_native | wins_entire_grid | none observed |
| 512 | roomy | adaptive_eviction | wins_entire_grid | none observed |
| 512 | roomy | adaptive_exact | wins_entire_grid | none observed |
| 512 | roomy | group_int4 | mixed_grid | [0.75, 1] (win → no win) |
| 512 | roomy | raw_admit_if_fits | wins_entire_grid | none observed |
| 512 | roomy | raw_native | wins_entire_grid | none observed |
| 2048 | cancellation | adaptive_eviction | wins_entire_grid | none observed |
| 2048 | cancellation | adaptive_exact | wins_entire_grid | none observed |
| 2048 | cancellation | group_int4 | mixed_grid | [0.5, 0.75] (win → no win) |
| 2048 | cancellation | raw_admit_if_fits | wins_entire_grid | none observed |
| 2048 | cancellation | raw_native | wins_entire_grid | none observed |
| 2048 | pressure | adaptive_eviction | wins_entire_grid | none observed |
| 2048 | pressure | adaptive_exact | wins_entire_grid | none observed |
| 2048 | pressure | group_int4 | mixed_grid | [0.5, 0.75] (win → no win) |
| 2048 | pressure | raw_admit_if_fits | wins_entire_grid | none observed |
| 2048 | pressure | raw_native | wins_entire_grid | none observed |
| 2048 | roomy | adaptive_eviction | wins_entire_grid | none observed |
| 2048 | roomy | adaptive_exact | wins_entire_grid | none observed |
| 2048 | roomy | group_int4 | mixed_grid | [0.75, 1] (win → no win) |
| 2048 | roomy | raw_admit_if_fits | wins_entire_grid | none observed |
| 2048 | roomy | raw_native | wins_entire_grid | none observed |

Brackets are scale ranges, not interpolated thresholds. Consult `scaled_components_ms_per_native_mib` for encode/decode ms/MiB at each endpoint. No monotonicity is assumed.

Assumptions and limits:

- All reported sweep times are modeled counterfactuals, not measured speedups or dollars.
- No inference is rerun: the sweep cannot certify answer quality, latency SLOs, or throughput.
- Peak stored bytes count complete serialized host payloads, not active KV or GPU memory.
- Only lossy codec encode/decode costs scale; native framing and all measured export/import costs remain.
- Per-context component medians are normalized by native tensor MiB; scaling them linearly across case sizes is an assumption.
- Recompute-arm initial prefill and generation are held identical across policies. Free-generation inputs do not become a live equal-work experiment.
- Policy lifecycle overhead is reused from that policy's measured rows; missing raw_admit_if_fits overhead uses raw_native rows. Counterfactual overhead can differ.
- Every admitted payload pays export/encode, including later evicted or canceled payloads. Misses pay actual recompute-arm recomputation. Predicted eviction penalties are not charged twice.
- Events are synchronous and ordered as recorded. The modeled clock includes all work; no production idle intervals, queues, overlap or contention are inferred.
- Future resolution and recompute timings are used only when their events occur; admission receives current initial-prefill cost, shape, family and completed history.
- A grid crossing is only a bracket. Policy switches can make results nonmonotonic; no interpolated break-even cost is claimed.
- Scale one need not reproduce the live run: calibration costs, common generation work and modeled event times replace actual per-operation timing.
