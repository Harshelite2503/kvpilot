# Owned-cache Torch experiment

Device: `cuda`. This is a sequential reference-runner experiment, not a serving-throughput benchmark.

Mode: **equal_work**. Every policy consumes the same frozen continuation IDs for the same number of prediction steps, including EOS. These are teacher-forced computational controls, not generated answers; no quality score is assigned. Compare timings within this mode only.

Full-session time includes original prefill, pause/compression, restore or recomputation, generation and canceled-session work. A speed ratio above 1 means less full-session time than fixed INT4 in this run. Memory is peak retained serialized cache, not total GPU or process memory.

| Context target | Scenario | Policy | Mean full session (ms) | Speed ratio vs INT4 | Ratio vs admit-if-fits | Peak stored MiB | Correct / responses | Answer tokens identical to recompute |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 512 | cancellation | adaptive_eviction | 603.46 | 1.102× | 0.988× | 11.086 | n/a | n/a |
| 512 | cancellation | adaptive_exact | 617.44 | 1.077× | 0.966× | 11.098 | n/a | n/a |
| 512 | cancellation | group_int4 | 664.88 | 1.000× | 0.897× | 10.352 | n/a | n/a |
| 512 | cancellation | raw_admit_if_fits | 596.16 | 1.115× | 1.000× | 11.086 | n/a | n/a |
| 512 | cancellation | raw_native | 613.70 | 1.083× | 0.971× | 11.098 | n/a | n/a |
| 512 | cancellation | recompute | 654.59 | 1.016× | 0.911× | 0.000 | n/a | n/a |
| 512 | pressure | adaptive_eviction | 770.72 | 1.059× | 0.992× | 11.086 | n/a | n/a |
| 512 | pressure | adaptive_exact | 771.86 | 1.058× | 0.991× | 11.098 | n/a | n/a |
| 512 | pressure | group_int4 | 816.33 | 1.000× | 0.937× | 10.352 | n/a | n/a |
| 512 | pressure | raw_admit_if_fits | 764.73 | 1.067× | 1.000× | 11.086 | n/a | n/a |
| 512 | pressure | raw_native | 783.65 | 1.042× | 0.976× | 11.098 | n/a | n/a |
| 512 | pressure | recompute | 787.83 | 1.036× | 0.971× | 0.000 | n/a | n/a |
| 512 | roomy | adaptive_eviction | 711.62 | 1.155× | 1.000× | 44.240 | n/a | n/a |
| 512 | roomy | adaptive_exact | 707.13 | 1.162× | 1.006× | 44.240 | n/a | n/a |
| 512 | roomy | group_int4 | 821.77 | 1.000× | 0.866× | 11.822 | n/a | n/a |
| 512 | roomy | raw_admit_if_fits | 711.69 | 1.155× | 1.000× | 44.240 | n/a | n/a |
| 512 | roomy | raw_native | 710.91 | 1.156× | 1.001× | 44.240 | n/a | n/a |
| 512 | roomy | recompute | 789.38 | 1.041× | 0.902× | 0.000 | n/a | n/a |
| 2048 | cancellation | adaptive_eviction | 1100.24 | 1.204× | 0.991× | 47.145 | n/a | n/a |
| 2048 | cancellation | adaptive_exact | 1125.26 | 1.177× | 0.969× | 47.133 | n/a | n/a |
| 2048 | cancellation | group_int4 | 1324.92 | 1.000× | 0.823× | 43.818 | n/a | n/a |
| 2048 | cancellation | raw_admit_if_fits | 1090.25 | 1.215× | 1.000× | 47.110 | n/a | n/a |
| 2048 | cancellation | raw_native | 1121.76 | 1.181× | 0.972× | 47.133 | n/a | n/a |
| 2048 | cancellation | recompute | 1152.48 | 1.150× | 0.946× | 0.000 | n/a | n/a |
| 2048 | pressure | adaptive_eviction | 1327.25 | 1.162× | 1.005× | 47.110 | n/a | n/a |
| 2048 | pressure | adaptive_exact | 1375.37 | 1.121× | 0.969× | 47.133 | n/a | n/a |
| 2048 | pressure | group_int4 | 1541.97 | 1.000× | 0.865× | 43.818 | n/a | n/a |
| 2048 | pressure | raw_admit_if_fits | 1333.31 | 1.156× | 1.000× | 47.110 | n/a | n/a |
| 2048 | pressure | raw_native | 1371.86 | 1.124× | 0.972× | 47.133 | n/a | n/a |
| 2048 | pressure | recompute | 1422.70 | 1.084× | 0.937× | 0.000 | n/a | n/a |
| 2048 | roomy | adaptive_eviction | 1088.00 | 1.379× | 1.022× | 188.241 | n/a | n/a |
| 2048 | roomy | adaptive_exact | 1102.25 | 1.362× | 1.009× | 188.241 | n/a | n/a |
| 2048 | roomy | group_int4 | 1500.78 | 1.000× | 0.741× | 50.073 | n/a | n/a |
| 2048 | roomy | raw_admit_if_fits | 1111.79 | 1.350× | 1.000× | 188.241 | n/a | n/a |
| 2048 | roomy | raw_native | 1085.66 | 1.382× | 1.024× | 188.241 | n/a | n/a |
| 2048 | roomy | recompute | 1402.28 | 1.070× | 0.793× | 0.000 | n/a | n/a |

These are descriptive results on generated lookup, two-hop and arithmetic tasks. Repeated questions are not independent quality observations. Unchanged accuracy does not imply unchanged answers. No quality-preservation or general performance claim is certified.

`summary.json` also reports p95 resume time, truncations, baseline-relative quality regressions, sampled process RSS and CUDA allocator peaks. RSS sampling can miss short peaks. CPU compression follows native export, so compressed stored bytes are not reduced GPU-to-host transfer bytes.

Run `python scripts/validate_p100_results.py RUN_DIRECTORY` to independently audit archive hashes, accounting, completeness and scores.
